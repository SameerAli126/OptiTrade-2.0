import React, { useState, useEffect } from 'react';
import {
    GridComponent,
    ColumnDirective,
    ColumnsDirective,
    Page,
    Inject,
    Filter,
    Group
} from '@syncfusion/ej2-react-grids';

const DashScreener = () => {
    const [stocks, setStocks] = useState([]);

    useEffect(() => {
        const fetchStocks = async () => {
            try {
                const response = await fetch('https://archlinux.tail9023a4.ts.net/stocks');
                const data = await response.json();
                setStocks(data);
            } catch (error) {
                console.error('Error fetching stocks:', error);
            }
        };

        fetchStocks();
    }, []);

    const handleSymbolClick = (symbol) => {
        console.log(`Symbol clicked: ${symbol}`);
        // Implement navigation or other logic here
    };

    return (
        <div style={{ margin: '10%', marginTop: '5%', marginLeft: '0%', maxWidth: '85%', overflowX: 'auto' }}>
            <GridComponent
                dataSource={stocks}
                allowPaging={true}
                pageSettings={{ pageSize: 10 }}
                allowFiltering={true}
                allowGrouping={true}
                filterSettings={{ type: 'Excel' }} // Enable Excel-style filtering
            >
                <ColumnsDirective>
                    <ColumnDirective
                        field='symbol'
                        headerText='Symbol'
                        width='100'
                        template={(props) => (
                            <span
                                onClick={() => handleSymbolClick(props.symbol)}
                                style={{ cursor: 'pointer', color: 'blue' }} // Change cursor and color
                            >
                                {props.symbol}
                            </span>
                        )}
                    />
                    <ColumnDirective field='name' headerText='Name' width='150' />
                    <ColumnDirective field='open' headerText='Open' textAlign='Right' width='100' />
                    <ColumnDirective field='high' headerText='High' textAlign='Right' width='100' />
                    <ColumnDirective field='low' headerText='Low' textAlign='Right' width='100' />
                    <ColumnDirective field='close' headerText='Close' textAlign='Right' width='100' />
                    <ColumnDirective field='volume' headerText='Volume' textAlign='Right' width='100' />
                    <ColumnDirective field='netchange' headerText='Net Change' textAlign='Right' width='100' />
                    <ColumnDirective field='pctchange' headerText='Pct Change' textAlign='Right' width='100' />
                    <ColumnDirective field='marketCap' headerText='Market Cap' textAlign='Right' width='150' />
                    <ColumnDirective field='industry' headerText='Industry' width='150' />
                    <ColumnDirective field='sector' headerText='Sector' width='150' />
                </ColumnsDirective>
                <Inject services={[Page, Filter, Group]} />
            </GridComponent>
        </div>
    );
}

export default DashScreener;
