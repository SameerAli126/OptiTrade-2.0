import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const BuySell = ({ stock }) => {
    if (!stock) {
        return <div className="bg-gray-800 text-white rounded-lg shadow-md p-4">Buy & Sell</div>;
    }

    const data = [
        { time: '10:00', price: stock.open },
        { time: '11:00', price: stock.high },
        { time: '12:00', price: stock.low },
        { time: '13:00', price: stock.close },
        { time: '14:00', price: stock.volume },
    ];

    return (
        <div className="bg-cyan-700 text-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold mb-4">{stock.symbol} - ${stock.close}</h2>
            <p>Open: ${stock.open}</p>
            <p>High: ${stock.high}</p>
            <p>Low: ${stock.low}</p>
            <p>Close: ${stock.close}</p>
            <p>Volume: {stock.volume}</p>
            <ResponsiveContainer width="100%" height={200}>
                <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="price" stroke="#82ca9d" />
                </LineChart>
            </ResponsiveContainer>
            <div className="flex justify-between mt-4">
                <button className="bg-green-500 text-white px-4 py-2 rounded">Buy</button>
                <button className="bg-red-500 text-white px-4 py-2 rounded">Sell</button>
            </div>
        </div>
    );
};

export default BuySell;
